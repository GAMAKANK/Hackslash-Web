function changeMode(a) {
    var element = document.body;
    element.classList.toggle("dark-mode");
  }