# Hackslash-Web
Creating a website clone for induction task of HACKSLASH <br>
Created basic structure using html-<br>
<b>Before adding images:</b><br>![hack1](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/3c7555ad-aa63-4b79-97d5-fea4d960eb82)<br>
<b>After adding images:</b><br>
![hack2](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/ac553357-a380-476b-afb6-24da3bc6928a)
![hack3](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/a097abbf-dd44-4a04-a69a-b92632bf9bf8)
![hack4](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/58600b4e-26e2-40d9-9b47-8db699fc910a)
![hack5](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/07ea0990-3495-4257-abde-8fcad55eb737)
<b>After editing it with css:</b><br>
![hack#1](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/dc5f2798-eaed-4aa0-9139-8b9d8549c316)
![hack#2](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/0cc1fd35-aee0-477c-8fa9-3c4eefb2319b)
![hack#3](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/45428c3f-e07f-4777-90b0-cc8c6598de52)
![hack#4](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/69eb8613-5632-447b-820d-f11cd9dc1561)
![hack#5](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/868eeda5-7583-48f5-b1f4-31a0a29ab3d8)
![hack#6](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/20672817-97da-4ebc-bbac-c60b2be78f91)
![hack#7](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/beb1d3c6-1976-4558-861d-24a301f3f1ca)

<br><br><b>Final look</b>![hack-nice -3](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/eb6991fb-d817-4c82-aec7-d8c03c9d4283)
![hack-nice -2JPG](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/fc88fa41-85b8-4b69-ac5d-f54d5720128a)
![hack-nice](https://github.com/GAMAKANK/Hackslash-Web/assets/155304917/bcca5080-fdc1-4bdf-b922-45a5d642b366)
